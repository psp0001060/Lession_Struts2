package org.apache.struts2.showcase.validation;

public class AjaxFormSubmitSuccessAction {
	public String execute() {
		return "success";
	}
}
